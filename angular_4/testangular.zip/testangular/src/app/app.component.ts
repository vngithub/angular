import { Component } from '@angular/core';

@Component({
  selector: 'app-core',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppCoreComponent {
  title = 'Tours of Heroes';
}
