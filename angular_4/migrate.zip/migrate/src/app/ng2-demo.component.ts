// src/app/ng2-demo.component.ts

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ng2-demo',
  template: `
    <h3>Angular 2 Demo Component</h3>
    <img width="150" src="..." />
  `
})
export class Ng2DemoComponent  {
}