import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { UpgradeModule, downgradeComponent } from '@angular/upgrade/static';
import { AppComponent } from './app.component';
import { Ng2demoComponent } from './ng2demo/ng2demo.component';

declare var angular: any;

angular.module('App')
  .directive(
    'appNg2demo',
    downgradeComponent({component: Ng2demoComponent})
  );

@NgModule({
  declarations: [
    AppComponent,
    Ng2demoComponent
  ],
  imports: [
    BrowserModule,
    UpgradeModule
  ],
  entryComponents: [
    Ng2demoComponent // Don't forget this!!!
  ],
  providers: [],
  //bootstrap: [AppComponent]
})
export class AppModule { 
	constructor(private upgrade: UpgradeModule) { }
	 ngDoBootstrap() {
    this.upgrade.bootstrap(document.body, ['App']);
  }
}
